<p style="text-align:center;color:#1e819e;font-size:1.3em;font-weight: bold;">
DD拼伞小程序
<br/>
keepUp队-阿布

![qrcode](/markdown/DDMatchLogo.jpg)

</p>

## 产品逻辑
![flowChart](/markdown/flowChart.png)


## 产品定位
##### 目标用户
该小程序的目标用户是高校内的在下雨或者暴晒的情景下具备伞的和不具备伞的学生。
##### 市场分析
2016年的深大宣传片有一个拼伞场景，从此以后拼伞被深大人所熟悉，后来出现了DD拼伞微信群，并且学生们异常活跃，一个校内的介绍拼伞群的推文的阅读量达到了7112.

<img src="/markdown/2.jpeg" width="20%" style="display:inline-block;margin-right:10px;">
<img src="/markdown/22.jpeg" width="20%" style="display:inline-block;margin-right:10px;">
<img src="/markdown/3.jpeg" width="20%" style="display:inline-block;margin-right:10px;">
<img src="/markdown/6.jpeg" width="20%" style="display:inline-block;margin-right:10px;">
<img src="/markdown/7.jpeg" width="18%" style="display:inline-block;margin-right:10px;">
<img src="/markdown/4.jpeg" width="30%" style="display:inline-block;margin-right:10px;">
<img src="/markdown/5.jpeg" width="30%" style="display:inline-block;margin-right:10px;">


####### 公众号链接: [点击这里](https://mp.weixin.qq.com/s/va2dJXzxTNbxY6jHXdLrMA) 

#### 使用场景
白天还是艳阳高照，晚上可能就是狂风暴雨。为了“对抗”说变脸就变脸的深圳天气.当下雨的时候忘记带伞的学生可以通过平台来发布拼伞的需求(出发时间，出发地点，目的地,报酬等),如果有伞的学生顺路，并且满意所给出的报酬则可以接单，与没有伞的学生一起顺路前往目的地。
#### 概念创新
- 借鉴了已经成功的独角兽公司Uber,滴滴等公司的商业模式,共享资源,并且符合深圳这种热带地区多雨的环境特点.
- 具有社交属性，有伞的学生和没有伞的学生可以认识结交朋友。

#### 贴近实际
- 深圳地处热带，经常下雨且深圳天气多变，出门的时候阳光明媚，但刚出门不久后就可能已经是狂风暴雨。
- 高校内学生密集，活动地点具有高度重合性(食堂，宿舍，教学楼,图书馆等).


## 产品
##### 简单化设计
该小程序设计的简单易懂,具有简单几步操作就可以完成发布需求，接单等操作。
##### 设计美观
该小程序以暖色橙色为主调,充分的展示了该小程序的互帮互助的性质。
#### 运营规范
该小程序给用户提供分享功能,可以分享到群/好友，并且可以分享到朋友圈，用户具有自主权利，不存在过度营销。


## 技术
##### 合理性
该小程序使用了小程序云开发，服务器稳定。
##### 可靠性
充分考虑了边界条件，比如用户不同意授权，用户点击取消接单等情况，具有良好的可靠性。















